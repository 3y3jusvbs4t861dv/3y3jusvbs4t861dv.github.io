# Cloudflare Worker + KV API

This is an example configuration for the EXISTING Cloudflare Worker
`3y3jusvbs4t861dv-github-io` with the KV namespace `MY_STORAGE` bound as `MY_KV`.

## Installation in your existing GitHub repository

Copy `wrangler.jsonc` to the repository root, `worker/index.js` into a `worker` folder,
and `.assetsignore` into the repository root. Keep existing website files in place.

If you already have `wrangler.jsonc`, review and merge its settings instead of
blindly replacing it. The provided config assumes your static site uses the repo root (`.`)
as the output directory, as your first Cloudflare deploy log indicated.

Before committing, check whether your site needs files under `worker/`; if so,
change the Worker source folder and `.assetsignore` rule to avoid excluding them.

In Cloudflare Workers & Pages > your Worker > Settings > Variables and Secrets > Add,
create a **Secret** named `API_WRITE_TOKEN` containing a long random value. Deploy.
This is NOT your Cloudflare account API token. Do NOT put it in GitHub or public JS.

Commit the files to `main` to trigger Cloudflare deployment.

## Endpoints

- GET /api/data -- public read: returns a JSON object, `{}` if empty.
- POST /api/data -- authenticated write: sends JSON body and
  `Authorization: Bearer <API_WRITE_TOKEN>`; requires Content-Type application/json.
  Max request body size: 64 KB.

Example GET from your Cloudflare-hosted site:

```js
const data = await (await fetch('/api/data')).json();
```

Example write from trusted interactive admin-only code, never embed the token in
public source files:

```js
const token = prompt('Write token');
const response = await fetch('/api/data', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  },
  body: JSON.stringify({ links: [] }),
});
console.log(response.status, await response.json());
```

## Important limitations

- GET is public! Do not store confidential data in this KV key.
- Write token must be kept private. Do not commit it to GitHub or hardcode it in HTML.
- If the site is served from github.io rather than the Workers domain, `'/api/data'`
  points to GitHub Pages, NOT Cloudflare. Use your Worker URL and configure CORS
  explicitly for your allowed origin, or instead serve the website on the Worker.
- A POST replaces the entire `site_data` key. Multiple simultaneous editors can
  overwrite each other's updates. KV is eventually consistent, so updates may
  take up to ~60 seconds to appear globally.
- You can protect GET too, if the information should be private.
